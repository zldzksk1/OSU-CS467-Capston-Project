import { createContext } from "react";

const RespondentContext = createContext();

export default RespondentContext;